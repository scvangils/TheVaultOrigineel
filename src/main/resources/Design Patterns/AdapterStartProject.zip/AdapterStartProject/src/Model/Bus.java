// Created by S.C. van Gils
// Creation date 23-12-2021
/**
 * Dit bustype rijdt op elektriciteit, geleverd via laadpalen van Vattenfall.
 * De busmaatschappij is recent echter gefuseerd met een maatschappij die bussen
 * heeft die worden opgeladen via laadpalen van Eneco.
 * Om zijn bussen ook in de remises van de andere maatschappij op te kunnen laden is het volgende nodig:
 * Van de VattenfallLaadpaal is het vermogen bekend. Dit maakt het eenvoudig te bepalen
 * hoe lang het duurt voordat de bus is opgeladen. (Methode staat in de Launcher)
 * Van de EnecoLaadpalen is het Voltage (vast) en het Amperage (variabel) bekend.
 * Zorg met behulp van een behulp van een adapter dat de methode in de Launcher gebruikt kan worden
 * om te bepalen of een EnecoLaadpaal snel genoeg is.
 * Hint: W = V * A
 * Hint: je hebt de (al gegeven) no-args constructor van VattenfallLaadpaal nodig.
 *
 */

package Model;

public class Bus{

    private VattenfallLaadpaal vattenfallLaadpaal;
    private final static double ACCU_CAPACITEIT_IN_KWH = 400.0;

    public Bus(VattenfallLaadpaal vattenfallLaadpaal) {
        super();
        this.vattenfallLaadpaal = vattenfallLaadpaal;
    }

    public void rijdtOpDeWeg(){
        System.out.println("Ik rijd op de weg!");
    }

    public void setVattenfallLaadpaal(VattenfallLaadpaal vattenfallLaadpaal) {
        this.vattenfallLaadpaal = vattenfallLaadpaal;
    }

    public double oplaadTijdInUren(){
    return ACCU_CAPACITEIT_IN_KWH * 1000 / vattenfallLaadpaal.getVermogen();
    }
}
