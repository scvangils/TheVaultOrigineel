// Created by S.C. van Gils
// Creation date 23-12-2021



package Model;

/**
 * De bestuurder kan vervoersmiddelen rijden die op de rails rijden
 * waarvan de tram de enige implementatie is.
 * Hij wil echter ook een bus kunnen rijden.
 * Met behulp van een adapter kunnen we dat hier bewerkstelligen.
 */
public class Bestuurder {

    private RailVervoer railVervoer;

    public Bestuurder(RailVervoer railVervoer) {
        super();
        this.railVervoer = railVervoer;
    }

    public void drive(){
        railVervoer.rijdtOpDeRails();
    }

}
