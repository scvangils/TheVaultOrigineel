package Model;

public interface RailVervoer {

    public void rijdtOpDeRails();
}
