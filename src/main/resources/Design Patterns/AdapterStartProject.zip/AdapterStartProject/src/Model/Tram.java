package Model;

public class Tram implements RailVervoer{

    public Tram(){
        super();
    }

    public void rijdtOpDeRails() {
        System.out.println("Ik rijd op de rails!");
    }
}
