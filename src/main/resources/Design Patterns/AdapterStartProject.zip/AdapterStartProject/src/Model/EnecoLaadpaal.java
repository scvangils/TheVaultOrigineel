// Created by S.C. van Gils
// Creation date 23-12-2021

package Model;

public class EnecoLaadpaal {

    private double amperage;
    private final static int VOLTAGE = 220;

    public EnecoLaadpaal(double amperage) {
        super();
        this.amperage = amperage;
    }

    public void setAmperage(double amperage) {
        this.amperage = amperage;
    }

    public double getAmperage() {
        return amperage;
    }
    public int getVoltage(){
        return VOLTAGE;
    }
}
