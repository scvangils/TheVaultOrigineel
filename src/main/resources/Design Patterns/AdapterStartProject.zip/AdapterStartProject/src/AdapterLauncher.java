// Created by S.C. van Gils
// Creation date 23-12-2021

import Model.*;

public class AdapterLauncher {

    public static final double MAX_LAADTIJD = 10.0;

    public AdapterLauncher() {
        super();
    }

    public static void main(String[] args) {


        /**
         * Voor de opgaven zie de Bestuurder en de Bus-klassen
         */

    Tram tram = new Tram();
    Bestuurder bestuurder = new Bestuurder(tram);
    bestuurder.drive();

    VattenfallLaadpaal vattenfallLaadpaal = new VattenfallLaadpaal(30000);
    Bus bus =  new Bus(vattenfallLaadpaal);
    laadtSnelGenoegOp(bus);
    bus.setVattenfallLaadpaal(new VattenfallLaadpaal(50000));
    laadtSnelGenoegOp(bus);

    }
    public static void laadtSnelGenoegOp(Bus bus){
        if(bus.oplaadtijdInUren() > MAX_LAADTIJD){
            System.out.println("Deze laadpaal laadt te langzaam op");
        }
        else System.out.println("Deze laadpaal laadt snel genoeg");
    }
}
