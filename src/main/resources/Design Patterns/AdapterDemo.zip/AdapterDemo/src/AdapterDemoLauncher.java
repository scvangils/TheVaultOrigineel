// Created by S.C. van Gils
// Creation date 23-12-2021

import Model.*;

public class AdapterDemoLauncher {

    public static final double MAX_LAADTIJD = 10.0;

    public AdapterDemoLauncher() {
        super();
    }

    public static void main(String[] args) {
        VattenfallLaadpaal vattenfallToEnecoAdapter = new EnecoToVattenfallAdapter(new EnecoLaadpaal(200));
        VattenfallLaadpaal vattenfallLaadpaal = new VattenfallLaadpaal();
        vattenfallLaadpaal.setVermogen(50000);
        Bus bus = new Bus(vattenfallLaadpaal);
        Bus busMetAdapter = new Bus(vattenfallToEnecoAdapter);
        System.out.println(vattenfallToEnecoAdapter.getVermogen());
        System.out.println(busMetAdapter.oplaadtijdInUren());
        System.out.println(bus.oplaadtijdInUren());
        Bestuurder bestuurder = new Bestuurder(new BusToTramAdapter(bus));
        Bestuurder bestuurderTwee = new Bestuurder(new BusToTramAdapterAlt(new VattenfallLaadpaal()));
        Bestuurder tramBestuurder = new Bestuurder(new Tram());
        tramBestuurder.drive();
        bestuurder.drive();
        bestuurderTwee.drive();
        rijdTramMetBus(new BusToTramAdapter(bus));
    }

    public static void rijdTramMetBus(RailVervoer railVervoer){
        railVervoer.rijdtOpDeRails();
    }
    public static void laadtSnelGenoegOp(Bus bus){
        if(bus.oplaadtijdInUren() > MAX_LAADTIJD){
            System.out.println("Deze laadpaal laadt te langzaam op");
        }
        else System.out.println("Deze laadpaal laadt snel genoeg");
    }
}
