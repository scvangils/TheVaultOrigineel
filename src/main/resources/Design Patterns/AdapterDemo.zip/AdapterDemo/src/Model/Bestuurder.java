// Created by S.C. van Gils
// Creation date 23-12-2021

package Model;

public class Bestuurder {

    private RailVervoer railVervoer;

    public Bestuurder(RailVervoer railVervoer) {
        super();
        this.railVervoer = railVervoer;
    }

    public void drive(){
        railVervoer.rijdtOpDeRails();
    }

}
