// Created by S.C. van Gils
// Creation date 23-12-2021

package Model;

public class Bus implements WegVervoer{

    private final VattenfallLaadpaal vattenfallLaadpaal;
    private final static double ACCU_CAPACITEIT_IN_KWH = 400.0;

    public Bus(VattenfallLaadpaal vattenfallLaadpaal) {
        super();
        this.vattenfallLaadpaal = vattenfallLaadpaal;
    }

    public Bus() {
        this.vattenfallLaadpaal = new VattenfallLaadpaal();
    }

    @Override
    public void rijdtOpDeWeg(){
        System.out.println("Ik rijd op de weg!");
    }
    public double oplaadtijdInUren(){
    return ACCU_CAPACITEIT_IN_KWH * 1000 / vattenfallLaadpaal.getVermogen();
    }
}
