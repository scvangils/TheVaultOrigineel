package Model;

public interface WegVervoer {
    public void rijdtOpDeWeg();
}
