// Created by S.C. van Gils
// Creation date 23-12-2021

package Model;

public class EnecoToVattenfallAdapter extends VattenfallLaadpaal{

    private EnecoLaadpaal enecoLaadpaal;

    public EnecoToVattenfallAdapter(EnecoLaadpaal enecoLaadpaal) {
        super();
        this.enecoLaadpaal = enecoLaadpaal;
    }

    @Override
    public double getVermogen(){
        return enecoLaadpaal.getAmperage() * enecoLaadpaal.getVoltage();
    }
}
