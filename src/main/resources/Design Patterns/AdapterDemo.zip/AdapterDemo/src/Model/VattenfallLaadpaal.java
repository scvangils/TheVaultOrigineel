// Created by S.C. van Gils
// Creation date 23-12-2021

package Model;

public class VattenfallLaadpaal {

    private double vermogen;

    public VattenfallLaadpaal(double vermogen){
        super();
        this.vermogen = vermogen;
    }

    public VattenfallLaadpaal() {
        super();
    }
    public void setVermogen(double vermogen) {
        this.vermogen = vermogen;
    }
    public double getVermogen() {
        return vermogen;
    }
}
