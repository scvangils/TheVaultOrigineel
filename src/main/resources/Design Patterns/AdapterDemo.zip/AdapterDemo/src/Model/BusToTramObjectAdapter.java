// Created by S.C. van Gils
// Creation date 23-12-2021

package Model;

public class BusToTramAdapter implements RailVervoer{

    private Bus bus;

    public BusToTramAdapter(Bus bus) {
        super();
        this.bus = bus;

    }

    @Override
    public void rijdtOpDeRails() {
        bus.rijdtOpDeWeg();
    }
}
