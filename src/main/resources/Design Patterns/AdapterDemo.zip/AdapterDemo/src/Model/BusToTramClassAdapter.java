// Created by S.C. van Gils
// Creation date 16-1-2022

package Model;

public class BusToTramAdapterAlt extends Bus implements RailVervoer{

    public BusToTramAdapterAlt(VattenfallLaadpaal vattenfallLaadpaal) {
        super(vattenfallLaadpaal);

    }

    @Override
    public void rijdtOpDeRails() {
        rijdtOpDeWeg();
    }
}
